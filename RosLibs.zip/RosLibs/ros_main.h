#ifndef __ROS_MAIN_H
#define __ROS_MAIN_H

#ifdef __cplusplus
 extern "C" {
#endif
   
void setup(void);
void loop(void);
   
#ifdef __cplusplus
 }
#endif
#endif /* __ROS_MAIN_H */

